namespace BookSamples.Components.ActionResults
{
    public enum FeedType
    {
        Rss = 0,
        Atom = 1
    }
}