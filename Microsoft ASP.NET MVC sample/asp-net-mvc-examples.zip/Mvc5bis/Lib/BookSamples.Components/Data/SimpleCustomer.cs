﻿namespace BookSamples.Components.Data
{
    public class SimpleCustomer
    {
        public string Address { get; set; }
        public string Contact { get; set; }
        public string City { get; set; }
        public string Company { get; set; }
        public string Country { get; set; }
        public string Id { get; set; }
    }
}