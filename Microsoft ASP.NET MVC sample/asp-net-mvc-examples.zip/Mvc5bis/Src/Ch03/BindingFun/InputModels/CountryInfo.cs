﻿using System;

namespace BindingFun.InputModels
{
    public class CountryInfo  
    {
        public String Capital { get; set; }
        public String Continent { get; set; }
    }
}