﻿using System;

namespace BindingFun.InputModels
{
    public class RepeatText
    {
        public String Text { get; set; }
        public Int32 Number { get; set; }
    }
}
