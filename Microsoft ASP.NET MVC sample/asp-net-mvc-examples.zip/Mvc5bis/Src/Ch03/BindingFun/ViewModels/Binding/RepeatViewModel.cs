﻿using System;

namespace BindingFun.ViewModels.Binding
{
    public class RepeatViewModel : ViewModelBase
    {
        public String Text { get; set; }
        public Int32 Number { get; set; }
    }
}