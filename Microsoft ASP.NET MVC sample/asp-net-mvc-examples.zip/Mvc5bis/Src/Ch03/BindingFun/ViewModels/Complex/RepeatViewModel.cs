﻿using System;

namespace BindingFun.ViewModels.Complex
{
    public class RepeatViewModel : ViewModelBase
    {
        public String Text { get; set; }
        public Int32 Number { get; set; }
    }
}