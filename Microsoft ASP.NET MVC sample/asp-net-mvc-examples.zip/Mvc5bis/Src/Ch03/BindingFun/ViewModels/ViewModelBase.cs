﻿using System;

namespace BindingFun.ViewModels
{
    public class ViewModelBase
    {
        public String Title { get; set; }
    }
}
