﻿using System;

namespace Sep.ViewModels
{
    public class ViewModelBase
    {
        public String Title { get; set; }
    }
}