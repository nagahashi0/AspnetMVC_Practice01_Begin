﻿namespace DataAnnotations.ViewModels.Memo
{
    public enum Categories
    {
        Personal = 1,
        Work = 2,
        Social = 3
    }
}