﻿using System;

namespace DataAnnotations.ViewModels
{
    public class ViewModelBase
    {
        public String Title { get; set; }
    }
}