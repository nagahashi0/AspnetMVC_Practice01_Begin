﻿using System;

namespace TryCatch.ViewModels
{
    public class ViewModelBase
    {
        public String Title { get; set; }
    }
}