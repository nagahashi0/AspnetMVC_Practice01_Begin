using System;

namespace CachingDemo.Framework
{
    public class StateEntries
    {
        public static String CookieName = ".MyAppPref";
        public static String PreferredTextColor = "PreferredTextColor";
    }
}