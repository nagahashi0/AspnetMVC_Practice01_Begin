﻿using System;

namespace AutoLanguage.ViewModels
{
    public class ViewModelBase
    {
        public String Title { get; set; }
    }
}