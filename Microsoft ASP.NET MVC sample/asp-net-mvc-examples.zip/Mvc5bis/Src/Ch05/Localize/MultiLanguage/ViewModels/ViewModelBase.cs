﻿using System;

namespace MultiLanguage.ViewModels
{
    public class ViewModelBase
    {
        public String Title { get; set; }
    }
}