﻿using System;

namespace EmbRes.ViewModels
{
    public class ViewModelBase
    {
        public String Title { get; set; }
    }
}