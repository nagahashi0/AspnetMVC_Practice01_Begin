using System;

namespace AnyProvider.Framework
{
    public delegate String UserNameAdapterDelegate(String userName);
}