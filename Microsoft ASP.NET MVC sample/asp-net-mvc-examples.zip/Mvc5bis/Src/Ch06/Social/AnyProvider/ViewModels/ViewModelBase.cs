﻿using System;

namespace AnyProvider.ViewModels
{
    public class ViewModelBase
    {
        public String Title { get; set; }
    }
}