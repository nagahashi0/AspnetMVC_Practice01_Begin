using System;

namespace FatFree.Backend.Model
{
    public class MementoDate
    {
        public DateTime Date { get; set; }
        public String Description { get; set; }
        public Boolean IsRelative { get; set; }
    }
}