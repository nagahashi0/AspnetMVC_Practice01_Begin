﻿using System;

namespace FatFree.ViewModels.Shared
{
    public class FeaturedDate
    {
        public DateTime Date { get; set; }
        public Int32 DaysToGo { get; set; }
        public String Description { get; set; }
    }
}