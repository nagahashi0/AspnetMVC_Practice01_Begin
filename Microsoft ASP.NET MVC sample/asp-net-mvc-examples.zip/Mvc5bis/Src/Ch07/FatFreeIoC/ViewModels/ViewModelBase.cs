﻿using System;

namespace FatFreeIoC.ViewModels
{
    public class ViewModelBase
    {
        public String Title { get; set; }
    }
}