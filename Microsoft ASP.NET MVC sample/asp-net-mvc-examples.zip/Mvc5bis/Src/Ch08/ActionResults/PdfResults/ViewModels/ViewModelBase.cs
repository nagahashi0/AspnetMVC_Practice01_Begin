﻿using System;

namespace PdfResults.ViewModels
{
    public class ViewModelBase
    {
        public String Title { get; set; }
    }
}