using System;

namespace ResultsMix.Framework
{
    public class Country
    {
        public String Code { get; set; }
        public String Area { get; set; }
        public String Name { get; set; }
        public String Capital { get; set; }
    }
}