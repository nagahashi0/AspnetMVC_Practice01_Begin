﻿using System;

namespace ResultsMix.ViewModels
{
    public class ViewModelBase
    {
        public String Title { get; set; }
    }
}