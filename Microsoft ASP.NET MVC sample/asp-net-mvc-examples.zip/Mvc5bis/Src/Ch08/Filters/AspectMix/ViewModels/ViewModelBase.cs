﻿using System;

namespace AspectMix.ViewModels
{
    public class ViewModelBase
    {
        public String Title { get; set; }
    }
}